<?php 
    if (isset($_GET['url'])){
        $url=$_GET['url'];

        switch($url)
        {
            case 'tulis_laporan';
            include 'tulis_laporan.php';
            break;

            case 'lihat_laporan';
            include 'lihat_laporan.php';
            break;

            case 'detail_laporan';
            include 'detail_laporan.php';
            break;

            case 'lihat_tanggapan';
            include 'lihat_tanggapan.php';
            break;
        }
    }
    else
{
        ?>
        Welcome Di Website laporan dari Kelompok 2 <br><br>
        Anda Login Sebagai : <h2> <?php  echo $_SESSION['nama'];
} 
?>