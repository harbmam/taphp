<?php 
    require '../models/koneksi.php';
    $nik=$_POST['nik'];
    $nama=$_POST['nama'];
    $username=$_POST['username'];
    $pass=$_POST['password'];
    $telp=$_POST['telp'];

    $sql=mysqli_query($conn,"insert into masyarakat values('$nik','$nama','$username','$pass','$telp')");
    if ($sql){
        ?>
        <script type="text/javascript">
            alert ('Data Berhasil Disimpan, Silahkan Gunakan Untuk Login');
            window.location="../index.php";
            </script>
            <?php
    }
?>