<?php 
    require '../models/koneksi.php';
    $user=$_POST['username'];
    $pass=$_POST['password'];
    $sql=mysqli_query($conn,"select * from petugas where username='$user' and password='$pass'");
    $cek=mysqli_num_rows($sql);

        if ($cek>0)//jika ada
        {
            $data=mysqli_fetch_array($sql);
            if ($data['level']=="admin")
            {
            session_start();
            $_SESSION['id_petugas']=$data['id_petugas'];
            $_SESSION['username']=$user;
            $_SESSION['nama']=$data['nama_petugas'];
            $_SESSION['level']=$data['level'];

            header('location:../admin/admin.php');
            }
            else if ($data['level']=="petugas")
            {
            session_start();
            $_SESSION['username']=$user;
            $_SESSION['nama']=$data['nama_petugas'];
            $_SESSION['level']=$data['level'];

            header('location:../petugas/petugas.php');
        }
    }
else
        {
            ?>
        <script type="text/javascript">
            alert ('Username/Password salah, Silahkan Coba Lagi');
            window.location="../index2.php";
            </script>
            <?php
        }
?>